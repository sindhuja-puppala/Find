package TestingExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActualProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
