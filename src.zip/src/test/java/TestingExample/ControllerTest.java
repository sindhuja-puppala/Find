package TestingExample;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@WebMvcTest(ControllerTest.class)
class ControllerTest {

		@Autowired
		private MockMvc mockMvc;
		@MockBean
		private CricRepository cricrepo;
		@MockBean
		private CricService cricSer;
	     @Test
	     public void testGetCricketers() throws Exception
	     {
	    	 
	    	 Cricketer e=new Cricketer();
	 		e.setJerseyno(1);
	 		e.setName("virat");
	 		e.setTeam("Rcb");
	 		e.setTestranking(101);
	 		
	 		Cricketer e2=new Cricketer();
	 		e2.setJerseyno(2);
	 		e2.setName("dhoni");
	 		e2.setTeam("chennai");
	 		e2.setTestranking(102);
	 		List<Cricketer> elist=new ArrayList<>();
	 		elist.add(e);
	 		elist.add(e2);
	 		
	 Mockito.when(cricSer.getAll()).thenReturn(elist);
	 		
			String URI = "/cricketer";
			RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
					URI).accept(
					MediaType.APPLICATION_JSON);

			MvcResult result = mockMvc.perform(requestBuilder).andReturn();

			String expectedJson = this.mapToJson(elist);
			String outputInJson = result.getResponse().getContentAsString();
			assertThat(outputInJson).isEqualTo(expectedJson);
			System.out.print(outputInJson);
}
	     private String mapToJson(Object object) throws JsonProcessingException {
	  		ObjectMapper objectMapper = new ObjectMapper();
	  		return objectMapper.writeValueAsString(object);
	  	}
}
