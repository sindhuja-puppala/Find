insert into cricketer values(1,'virat','Rcb',101);
insert into cricketer values(2,'dhoni','chennai',102);
