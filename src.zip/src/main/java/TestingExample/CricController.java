package TestingExample;


import java.util.List;
import java.util.Optional;
//import org.springframework.kafka.core.KafkaTemplate;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

	@RestController
	@RequestMapping
	
	public class CricController {
		
		//KafkaTemplate<String,String> kakfaTemp;
		//@Autowired
		CricService cricService;
	 @ResponseBody
		@GetMapping("/cricketer")
		public List<Cricketer> getAll()
		{
			return  cricService.getAll();
		}
		@GetMapping("details/{Id}")
		public Optional<Cricketer> getCricketer(@PathVariable("Id") int jerseyno)
		{
			return this.cricService.findById(jerseyno);
		}
		@PostMapping("post")
		public void addEmp(@RequestBody Cricketer cricketer)
		{
			cricService.add(cricketer);
		}
		
		@DeleteMapping("/cricketer")
		public void delete(@RequestParam int jerseyno)
		{
			 cricService.deleteById(jerseyno);
		}
		@PutMapping("/put/{Id}")
		public void Update(@PathVariable("Id") int jerseyno,@RequestBody Cricketer cricketer)
		{
		cricService.save(cricketer);}	
		
		
}
