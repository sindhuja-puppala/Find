package TestingExample;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class CricService {
	
	
		public List<Cricketer> emp=new ArrayList();
		@Autowired
		private CricRepository cricRepository;

		
		public List<Cricketer> getAll() {
			// TODO Auto-generated method stub
			return (List<Cricketer>) cricRepository.findAll();
		}
		public Optional<Cricketer> findById(int Id) {
			// TODO Auto-generated method stub
			 
		return cricRepository.findById(Id);
		
		}
		public void add(Cricketer cricketer) {
			// TODO Auto-generated method stub
			cricRepository.save(cricketer);
		}
		public void deleteById(int jerseynoo) {
			// TODO Auto-generated method stub
			cricRepository.deleteById(jerseynoo);	
		}

		public void save(Cricketer cricketer) {
			// TODO Auto-generated method stub
			cricRepository.save(cricketer);
		}
		
	}
